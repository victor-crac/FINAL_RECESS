<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class customerController extends Controller
{
    //
     public function index()
    {
        # code...
        return view('customers');
    }
}
